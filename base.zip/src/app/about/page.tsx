
const AboutPage = () => {
    return (
        <div>page</div>
    )
}

export default AboutPage