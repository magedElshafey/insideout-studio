

const HomePage = () => {
    return (
        <div>page</div>
    )
}

export default HomePage