

const ContactPage = () => {
    return (
        <div>page</div>
    )
}

export default ContactPage