export const apiUrl: string = "https://appadvertisements.almasader.net/api/";
